import prismaClient from '../config/prismaConfig.js';

export const mainGETController = async (req, res) => {

}

export const mainPOSTController = async (req, res) => {

}