-- CreateTable
CREATE TABLE `Users` (
    `userId` INTEGER NOT NULL AUTO_INCREMENT,
    `firstName` VARCHAR(191) NOT NULL,
    `lastName` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `password` LONGBLOB NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `lastLogin` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `Users_userId_key`(`userId`),
    UNIQUE INDEX `Users_email_key`(`email`),
    PRIMARY KEY (`userId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `MeetData` (
    `meetId` INTEGER NOT NULL AUTO_INCREMENT,
    `meetCode` VARCHAR(191) NOT NULL,
    `startedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `endedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `meetTranscript` LONGBLOB NULL,
    `meetAdmin` INTEGER NOT NULL,

    UNIQUE INDEX `MeetData_meetId_key`(`meetId`),
    UNIQUE INDEX `MeetData_meetCode_key`(`meetCode`),
    PRIMARY KEY (`meetId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `RefreshTokens` (
    `refreshTokenId` INTEGER NOT NULL AUTO_INCREMENT,
    `refreshToken` VARCHAR(512) NOT NULL,
    `rtMappedUserId` INTEGER NOT NULL,

    UNIQUE INDEX `RefreshTokens_refreshTokenId_key`(`refreshTokenId`),
    UNIQUE INDEX `RefreshTokens_refreshToken_key`(`refreshToken`),
    PRIMARY KEY (`refreshTokenId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `UserMeetMap` (
    `UserMeetMapId` INTEGER NOT NULL,
    `mappedUserId` INTEGER NOT NULL,
    `mappedMeetId` INTEGER NOT NULL,

    UNIQUE INDEX `UserMeetMap_UserMeetMapId_key`(`UserMeetMapId`),
    UNIQUE INDEX `UserMeetMap_mappedUserId_mappedMeetId_key`(`mappedUserId`, `mappedMeetId`),
    PRIMARY KEY (`UserMeetMapId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Message` (
    `messageId` INTEGER NOT NULL AUTO_INCREMENT,
    `sentTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `message_body` VARCHAR(191) NOT NULL DEFAULT '',
    `mappedUserId` INTEGER NOT NULL,
    `mappedMeetId` INTEGER NOT NULL,

    UNIQUE INDEX `Message_messageId_key`(`messageId`),
    PRIMARY KEY (`messageId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `MeetData` ADD CONSTRAINT `MeetData_meetAdmin_fkey` FOREIGN KEY (`meetAdmin`) REFERENCES `Users`(`userId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `RefreshTokens` ADD CONSTRAINT `RefreshTokens_rtMappedUserId_fkey` FOREIGN KEY (`rtMappedUserId`) REFERENCES `Users`(`userId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `UserMeetMap` ADD CONSTRAINT `UserMeetMap_mappedUserId_fkey` FOREIGN KEY (`mappedUserId`) REFERENCES `Users`(`userId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `UserMeetMap` ADD CONSTRAINT `UserMeetMap_mappedMeetId_fkey` FOREIGN KEY (`mappedMeetId`) REFERENCES `MeetData`(`meetId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Message` ADD CONSTRAINT `Message_mappedUserId_fkey` FOREIGN KEY (`mappedUserId`) REFERENCES `Users`(`userId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Message` ADD CONSTRAINT `Message_mappedMeetId_fkey` FOREIGN KEY (`mappedMeetId`) REFERENCES `MeetData`(`meetId`) ON DELETE RESTRICT ON UPDATE CASCADE;
