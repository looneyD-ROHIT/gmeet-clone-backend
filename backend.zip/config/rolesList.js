const rolesList = {
    "host": 420,
    "user": 69,
}

export default rolesList